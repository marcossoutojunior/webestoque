# Controle de estoque em PHP

### Requisitos mínimos

Servidor Apache 2.4, PHP ^7.1 e MySQL ^5.7

Este código é referente ao tutorial desenvolvido no canal Fabrício Paixão no YouTube. https://www.youtube.com/fabriciopaixao

Playlist: https://www.youtube.com/watch?v=5P9djMO2Soo&list=PLBiFBs8xc7Wk7GJu_GmJQNtY4FebJ6H8x

Veja a vídeo aula 15 para instruções de como instalar em sua máquina.
Link: https://www.youtube.com/watch?v=mdBLoIJc9Sw&list=PLBiFBs8xc7Wk7GJu_GmJQNtY4FebJ6H8x&index=15
